package com.capgemini.spring.mvc.controller;

import org.springframework.stereotype.Controller;

public class HelloController {
	@Controller
	public String sayHello() {
		@
		return "hello";
	}

}
