package com.capgemini.newmvc.person.dao.impl;

import com.capgemini.newmvc.person.Person;
import com.capgemini.newmvc.person.dao.PersonDao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class PersonDaoImpl implements PersonDao{
	@Autowired
	private JdbcTemplate template;

	@Override
	public boolean addNew(Person person) {
		template.update("INSERT INTO PERSON VALUES(?,?)",
				new Object[] {person.getPersonId(),person.getPersonName()}); 
		return false;
	}

	@Override
	public List<Person> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Person person) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int personId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Person getPerson() {
		// TODO Auto-generated method stub
		return null;
	}
		
}
