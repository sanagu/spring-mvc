package com.capgemini.newmvc.person.service;

import java.util.List;

import com.capgemini.newmvc.person.Person;

public interface PersonService {
	void addNew(Person person);
	List<Person> getAll();
	void update(Person person);
	void delete(int personId);
	Person getPerson();
}
